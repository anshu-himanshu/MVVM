package com.ansh.mvvm

data class AnswersModel(
    val answers:String
)
